Customer and Product QR Code Generator
======================================

The Customer and Product QRCode Generator Helps You to Generate Unique
QR Codes to your Products or Customers

Installation
============
	- www.odoo.com/documentation/16.0/setup/install.html
	- Install our custom addon

License
-------
General Public License, Version 3 (LGPL v3).
(https://www.odoo.com/documentation/user/15.0/legal/licenses/licenses.html)

Company
-------
* 'Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developer:
(V14) Sarath Suresh @ Cybrosys
(V15) Midilaj V K @ Cybrosys
(V16) Athira P S @ Cybrosys


Contacts
--------
* Mail Contact : odoo@cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Further information
===================
HTML Description: `<static/description/index.html>`__

